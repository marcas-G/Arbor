Arbor Web UI Design Pack

final-pages/
01-workbench-tree-conversation.png
  Core desktop workbench: resizable Tree + Conversation layout.
02-pending-queue.png
  Human-governance pending queue and decision detail.
03-attention.png
  Read-only attention/risk monitoring feed and detail.
04-work-verification-detail.png
  Work detail with progress, verification, dependencies and activity.
05-usage.png
  Usage/cost/resource analytics view.
06-project-settings.png
  Project settings, members, providers, runtime environment.
07-mobile-workbench-conversation-tree-context.png
  Mobile conversation, work tree and context bottom-sheet concepts.

specs/
01-design-system.png
  Core visual tokens and component system.
02-auth-project-entry-global-states-components.png
  Authentication/project entry plus global state and component references.
03-design-system-entry-states-reference.png
  Consolidated reference sheet for implementation.

Notes
- These are UI references, not frozen backend semantics.
- Tree and Conversation are the primary Workbench surface.
- Conversation is Root Workspace only; child workspaces remain non-chat surfaces.
- Pending is actionable; Attention is read-only.
- Server remains the source of truth; WS is invalidation/refetch only.
